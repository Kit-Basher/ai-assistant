from __future__ import annotations

from functools import wraps
import json
import re
import threading
import uuid
from datetime import datetime, timezone
from typing import Any

from memory.db import MemoryDB

from agent.memory_contract import (
    PENDING_STATUS_ABORTED,
    PENDING_STATUS_DONE,
    PENDING_STATUS_EXPIRED,
    PENDING_STATUS_READY_TO_RESUME,
    PENDING_STATUS_WAITING_FOR_USER,
    build_memory_summary,
    deterministic_memory_snapshot,
    is_meta_action,
    normalize_pending_item,
    normalize_thread_state,
)


_FOLLOWUP_POSITIVE = {
    "yes",
    "y",
    "ok",
    "okay",
    "sure",
    "do it",
    "go ahead",
    "that one",
    "show me more",
}
_FOLLOWUP_NEGATIVE = {"no", "n", "cancel", "stop", "never mind", "nevermind"}
_NEW_THREAD_PHRASES = {"new topic", "different topic", "switch topic", "separate question"}
_MANAGED_RUNTIME_SUFFIXES = (
    "thread_state",
    "pending_items",
    "last_meaningful_user_request",
    "last_agent_action",
)


def _now_epoch() -> int:
    return int(datetime.now(timezone.utc).timestamp())


def _normalize_text(value: str | None) -> str:
    return " ".join(str(value or "").strip().lower().split())


def _with_runtime_lock(method):
    @wraps(method)
    def _wrapped(self, *args: Any, **kwargs: Any):
        with self._lock:
            return method(self, *args, **kwargs)

    return _wrapped


class MemoryRuntime:
    def __init__(self, db: MemoryDB) -> None:
        self._db = db
        self._lock = threading.RLock()

    @staticmethod
    def _thread_key(user_id: str) -> str:
        return f"memory_runtime:{str(user_id).strip()}:thread_state"

    @staticmethod
    def _pending_key(user_id: str) -> str:
        return f"memory_runtime:{str(user_id).strip()}:pending_items"

    @staticmethod
    def _last_request_key(user_id: str) -> str:
        return f"memory_runtime:{str(user_id).strip()}:last_meaningful_user_request"

    @staticmethod
    def _last_action_key(user_id: str) -> str:
        return f"memory_runtime:{str(user_id).strip()}:last_agent_action"

    @staticmethod
    def _managed_runtime_key(user_id: str, suffix: str) -> str:
        normalized_suffix = str(suffix or "").strip()
        return f"memory_runtime:{str(user_id).strip()}:{normalized_suffix}"

    @staticmethod
    def _managed_runtime_prefix() -> str:
        return "memory_runtime:"

    @staticmethod
    def _user_id_from_managed_key(key: str) -> tuple[str | None, str | None]:
        normalized = str(key or "").strip()
        prefix = MemoryRuntime._managed_runtime_prefix()
        if not normalized.startswith(prefix):
            return None, None
        remainder = normalized[len(prefix) :]
        for suffix in _MANAGED_RUNTIME_SUFFIXES:
            marker = f":{suffix}"
            if remainder.endswith(marker):
                user_id = remainder[: -len(marker)]
                return user_id, suffix
        return None, None

    @staticmethod
    def _inspect_raw_json(raw: str | None, *, expected_type: type[Any]) -> dict[str, Any]:
        if raw is None:
            return {
                "status": "missing",
                "healthy": True,
                "error": None,
                "parsed": None,
                "raw_preview": None,
            }
        raw_text = str(raw)
        preview = raw_text if len(raw_text) <= 160 else raw_text[:157] + "..."
        try:
            parsed = json.loads(raw_text)
        except (TypeError, ValueError):
            return {
                "status": "corrupt_json",
                "healthy": False,
                "error": "invalid_json",
                "parsed": None,
                "raw_preview": preview,
            }
        if not isinstance(parsed, expected_type):
            return {
                "status": "invalid_type",
                "healthy": False,
                "error": f"expected_{expected_type.__name__}",
                "parsed": None,
                "raw_preview": preview,
            }
        return {
            "status": "ok",
            "healthy": True,
            "error": None,
            "parsed": parsed,
            "raw_preview": preview,
        }

    def _load_json(self, key: str, default: Any) -> Any:
        raw = self._db.get_user_pref(key)
        if not raw:
            return default
        try:
            parsed = json.loads(raw)
        except (TypeError, ValueError):
            return default
        return parsed

    def _save_json(self, key: str, payload: Any) -> None:
        self._db.set_user_pref(
            key,
            json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(",", ":")),
        )

    @staticmethod
    def _default_thread_id(user_id: str) -> str:
        return f"user:{str(user_id).strip() or 'unknown'}"

    @_with_runtime_lock
    def get_thread_state(self, user_id: str) -> dict[str, Any]:
        parsed = self._load_json(self._thread_key(user_id), {})
        if not isinstance(parsed, dict):
            parsed = {}
        normalized = normalize_thread_state(
            parsed,
            user_id=user_id,
            default_thread_id=self._default_thread_id(user_id),
        )
        return normalized

    @_with_runtime_lock
    def set_thread_state(self, user_id: str, **updates: Any) -> dict[str, Any]:
        current = self.get_thread_state(user_id)
        merged = dict(current)
        for key, value in updates.items():
            merged[str(key)] = value
        merged["user_id"] = str(user_id)
        merged["updated_at"] = _now_epoch()
        normalized = normalize_thread_state(
            merged,
            user_id=user_id,
            default_thread_id=self._default_thread_id(user_id),
        )
        self._save_json(self._thread_key(user_id), normalized)
        return normalized

    @_with_runtime_lock
    def set_current_topic(
        self,
        user_id: str,
        *,
        topic: str | None,
        runtime_mode: str | None = None,
        last_tool: str | None = None,
        status: str = "active",
    ) -> dict[str, Any]:
        updates: dict[str, Any] = {"current_topic": topic, "status": status}
        if runtime_mode is not None:
            updates["runtime_mode"] = runtime_mode
        if last_tool is not None:
            updates["last_tool"] = last_tool
        return self.set_thread_state(user_id, **updates)

    @_with_runtime_lock
    def set_last_tool(self, user_id: str, tool_name: str | None) -> dict[str, Any]:
        return self.set_thread_state(user_id, last_tool=(str(tool_name).strip().lower() or None))

    @_with_runtime_lock
    def record_user_request(self, user_id: str, text: str) -> None:
        cleaned = str(text or "").strip()
        if not cleaned:
            return
        self._db.set_user_pref(self._last_request_key(user_id), cleaned)

    @_with_runtime_lock
    def record_agent_action(self, user_id: str, text: str, *, action_kind: str | None = None) -> bool:
        if is_meta_action(action_kind):
            return False
        cleaned = " ".join(str(text or "").split()).strip()
        if not cleaned:
            return False
        self._db.set_user_pref(self._last_action_key(user_id), cleaned)
        return True

    def _load_pending_items(self, user_id: str) -> list[dict[str, Any]]:
        parsed = self._load_json(self._pending_key(user_id), [])
        if not isinstance(parsed, list):
            parsed = []
        thread_id = self.get_thread_state(user_id).get("thread_id") or self._default_thread_id(user_id)
        normalized = [
            normalize_pending_item(item, default_thread_id=str(thread_id))
            for item in parsed
            if isinstance(item, dict)
        ]
        normalized.sort(key=lambda row: (int(row.get("created_at") or 0), str(row.get("pending_id") or "")))
        return normalized

    def _save_pending_items(self, user_id: str, rows: list[dict[str, Any]]) -> None:
        ordered = sorted(
            [normalize_pending_item(row, default_thread_id=self._default_thread_id(user_id)) for row in rows],
            key=lambda row: (int(row.get("created_at") or 0), str(row.get("pending_id") or "")),
        )
        self._save_json(self._pending_key(user_id), ordered)

    @_with_runtime_lock
    def clear_expired_pending_items(self, user_id: str, *, now_ts: int | None = None) -> int:
        timestamp = int(now_ts if isinstance(now_ts, int) else _now_epoch())
        changed = 0
        rows = self._load_pending_items(user_id)
        for row in rows:
            if row["status"] in {PENDING_STATUS_DONE, PENDING_STATUS_ABORTED, PENDING_STATUS_EXPIRED}:
                continue
            if int(row.get("expires_at") or 0) <= timestamp:
                row["status"] = PENDING_STATUS_EXPIRED
                changed += 1
        if changed:
            self._save_pending_items(user_id, rows)
        return changed

    @_with_runtime_lock
    def list_pending_items(
        self,
        user_id: str,
        *,
        thread_id: str | None = None,
        include_expired: bool = False,
        now_ts: int | None = None,
    ) -> list[dict[str, Any]]:
        timestamp = int(now_ts if isinstance(now_ts, int) else _now_epoch())
        self.clear_expired_pending_items(user_id, now_ts=timestamp)
        rows = self._load_pending_items(user_id)
        out: list[dict[str, Any]] = []
        for row in rows:
            if thread_id and str(row.get("thread_id") or "").strip() != str(thread_id).strip():
                continue
            if not include_expired and row["status"] == PENDING_STATUS_EXPIRED:
                continue
            out.append(dict(row))
        out.sort(key=lambda row: (int(row.get("created_at") or 0), str(row.get("pending_id") or "")))
        return out

    @_with_runtime_lock
    def add_pending_item(self, user_id: str, item: dict[str, Any]) -> dict[str, Any]:
        rows = self._load_pending_items(user_id)
        thread_id = str(item.get("thread_id") or "").strip() or self.get_thread_state(user_id)["thread_id"]
        normalized = normalize_pending_item(
            {
                "pending_id": item.get("pending_id") or f"pending-{uuid.uuid4().hex[:10]}",
                "kind": item.get("kind"),
                "origin_tool": item.get("origin_tool"),
                "question": item.get("question"),
                "options": item.get("options") if isinstance(item.get("options"), list) else [],
                "created_at": item.get("created_at") or _now_epoch(),
                "expires_at": item.get("expires_at") or (_now_epoch() + 600),
                "thread_id": thread_id,
                "status": item.get("status") or PENDING_STATUS_WAITING_FOR_USER,
            },
            default_thread_id=thread_id,
        )
        context = item.get("context") if isinstance(item.get("context"), dict) else {}
        if context:
            normalized["context"] = {str(k): context[k] for k in sorted(context.keys())}
        rows = [row for row in rows if str(row.get("pending_id") or "") != normalized["pending_id"]]
        rows.append(normalized)
        self._save_pending_items(user_id, rows)
        return normalized

    @_with_runtime_lock
    def set_pending_status(self, user_id: str, pending_id: str, status: str) -> bool:
        rows = self._load_pending_items(user_id)
        changed = False
        normalized_status = str(status or "").strip().upper()
        if normalized_status not in {
            PENDING_STATUS_WAITING_FOR_USER,
            PENDING_STATUS_READY_TO_RESUME,
            PENDING_STATUS_EXPIRED,
            PENDING_STATUS_DONE,
            PENDING_STATUS_ABORTED,
        }:
            normalized_status = PENDING_STATUS_ABORTED
        for row in rows:
            if str(row.get("pending_id") or "") != str(pending_id or ""):
                continue
            row["status"] = normalized_status
            changed = True
        if changed:
            self._save_pending_items(user_id, rows)
        return changed

    @_with_runtime_lock
    def abort_pending_for_thread(self, user_id: str, thread_id: str) -> int:
        rows = self._load_pending_items(user_id)
        changed = 0
        for row in rows:
            if str(row.get("thread_id") or "").strip() != str(thread_id or "").strip():
                continue
            if row["status"] in {PENDING_STATUS_DONE, PENDING_STATUS_ABORTED, PENDING_STATUS_EXPIRED}:
                continue
            row["status"] = PENDING_STATUS_ABORTED
            changed += 1
        if changed:
            self._save_pending_items(user_id, rows)
        return changed

    @_with_runtime_lock
    def remove_pending_item(self, user_id: str, pending_id: str) -> bool:
        rows = self._load_pending_items(user_id)
        kept = [row for row in rows if str(row.get("pending_id") or "") != str(pending_id or "")]
        if len(kept) == len(rows):
            return False
        self._save_pending_items(user_id, kept)
        return True

    @_with_runtime_lock
    def resolve_followup(self, user_id: str, text: str, current_thread_id: str) -> dict[str, Any]:
        normalized = _normalize_text(text)
        if not normalized:
            return {"type": "none", "reason": "empty"}
        kind: str | None = None
        if normalized in _FOLLOWUP_POSITIVE:
            kind = "accept"
        elif normalized in _FOLLOWUP_NEGATIVE:
            kind = "decline"
        elif normalized in {"show me more", "details", "that one"}:
            kind = "details"
        if kind is None:
            return {"type": "none", "reason": "not_followup"}

        rows = [
            row
            for row in self.list_pending_items(
                user_id,
                thread_id=current_thread_id,
                include_expired=True,
            )
            if row["status"] in {PENDING_STATUS_WAITING_FOR_USER, PENDING_STATUS_READY_TO_RESUME}
        ]
        expired_rows = [
            row
            for row in self.list_pending_items(
                user_id,
                thread_id=current_thread_id,
                include_expired=True,
            )
            if row["status"] == PENDING_STATUS_EXPIRED
        ]
        if not rows:
            if expired_rows:
                return {
                    "type": "expired",
                    "reason": "pending_expired",
                    "intent": kind,
                    "pending_ids": [str(row.get("pending_id") or "") for row in expired_rows],
                }
            return {"type": "none", "reason": "no_pending", "intent": kind}
        if len(rows) > 1:
            return {
                "type": "ambiguous",
                "reason": "multiple_pending",
                "intent": kind,
                "pending_ids": [str(row.get("pending_id") or "") for row in rows],
            }
        return {"type": "match", "reason": "single_pending", "intent": kind, "pending_item": dict(rows[0])}

    @_with_runtime_lock
    def is_ambiguous_followup(self, user_id: str, text: str, current_thread_id: str) -> bool:
        result = self.resolve_followup(user_id, text, current_thread_id)
        return str(result.get("type") or "") == "ambiguous"

    @_with_runtime_lock
    def should_start_new_thread(self, user_id: str, text: str, current_thread_id: str) -> bool:
        _ = current_thread_id
        normalized = _normalize_text(text)
        if not normalized:
            return False
        if any(phrase in normalized for phrase in _NEW_THREAD_PHRASES):
            return True
        thread = self.get_thread_state(user_id)
        topic = _normalize_text(str(thread.get("current_topic") or ""))
        if not topic:
            return False
        if len(normalized.split()) < 4:
            return False
        topic_tokens = {token for token in re.split(r"[^a-z0-9]+", topic) if token}
        text_tokens = {token for token in re.split(r"[^a-z0-9]+", normalized) if token}
        if not topic_tokens or not text_tokens:
            return False
        overlap = topic_tokens.intersection(text_tokens)
        return len(overlap) == 0 and any(trigger in normalized for trigger in {"instead", "different", "new"})

    @_with_runtime_lock
    def get_memory_summary(self, user_id: str, thread_id: str | None = None) -> dict[str, Any]:
        thread = self.get_thread_state(user_id)
        if thread_id and str(thread_id).strip() and str(thread.get("thread_id") or "").strip() != str(thread_id).strip():
            thread = self.set_thread_state(user_id, thread_id=str(thread_id).strip())
        pending = self.list_pending_items(user_id, thread_id=str(thread.get("thread_id") or "").strip())
        return build_memory_summary(
            thread_state=thread,
            pending_items=pending,
            last_meaningful_user_request=self._db.get_user_pref(self._last_request_key(user_id)),
            last_agent_action=self._db.get_user_pref(self._last_action_key(user_id)),
        )

    @_with_runtime_lock
    def deterministic_snapshot(self, user_id: str, thread_id: str | None = None) -> dict[str, Any]:
        thread = self.get_thread_state(user_id)
        if thread_id and str(thread_id).strip():
            thread = self.set_thread_state(user_id, thread_id=str(thread_id).strip())
        thread_id_value = str(thread.get("thread_id") or "").strip() or self._default_thread_id(user_id)
        pending = self.list_pending_items(user_id, thread_id=thread_id_value, include_expired=True)
        return deterministic_memory_snapshot(
            thread_state=thread,
            pending_items=pending,
            last_meaningful_user_request=self._db.get_user_pref(self._last_request_key(user_id)),
            last_agent_action=self._db.get_user_pref(self._last_action_key(user_id)),
        )

    @_with_runtime_lock
    def inspect_user_state(self, user_id: str) -> dict[str, Any]:
        thread_key = self._thread_key(user_id)
        pending_key = self._pending_key(user_id)
        last_request_key = self._last_request_key(user_id)
        last_action_key = self._last_action_key(user_id)

        thread_inspect = self._inspect_raw_json(
            self._db.get_user_pref(thread_key),
            expected_type=dict,
        )
        pending_inspect = self._inspect_raw_json(
            self._db.get_user_pref(pending_key),
            expected_type=list,
        )
        thread_parsed = thread_inspect.get("parsed") if isinstance(thread_inspect.get("parsed"), dict) else None
        pending_parsed = pending_inspect.get("parsed") if isinstance(pending_inspect.get("parsed"), list) else None
        active_thread_id = None
        pending_count = 0
        if thread_parsed is not None:
            active_thread_id = str(thread_parsed.get("thread_id") or "").strip() or None
        if pending_parsed is not None:
            pending_count = len([row for row in pending_parsed if isinstance(row, dict)])
        entries = [
            {
                "key": thread_key,
                "kind": "thread_state",
                "status": thread_inspect["status"],
                "healthy": bool(thread_inspect["healthy"]),
                "error": thread_inspect["error"],
                "raw_preview": thread_inspect["raw_preview"],
            },
            {
                "key": pending_key,
                "kind": "pending_items",
                "status": pending_inspect["status"],
                "healthy": bool(pending_inspect["healthy"]),
                "error": pending_inspect["error"],
                "raw_preview": pending_inspect["raw_preview"],
            },
            {
                "key": last_request_key,
                "kind": "last_meaningful_user_request",
                "status": "ok" if self._db.get_user_pref(last_request_key) is not None else "missing",
                "healthy": True,
                "error": None,
                "raw_preview": None,
            },
            {
                "key": last_action_key,
                "kind": "last_agent_action",
                "status": "ok" if self._db.get_user_pref(last_action_key) is not None else "missing",
                "healthy": True,
                "error": None,
                "raw_preview": None,
            },
        ]
        corrupt_entries = [dict(entry) for entry in entries if not bool(entry.get("healthy", False))]
        return {
            "user_id": str(user_id),
            "healthy": not corrupt_entries,
            "active_thread_id": active_thread_id,
            "pending_count": pending_count,
            "entries": entries,
            "corrupt_entries": corrupt_entries,
        }

    @_with_runtime_lock
    def inspect_all_state(self) -> dict[str, Any]:
        rows = self._db.list_user_prefs()
        by_user: dict[str, dict[str, Any]] = {}
        unknown_keys: list[str] = []
        for row in rows:
            key = str((row or {}).get("key") or "").strip()
            user_id, suffix = self._user_id_from_managed_key(key)
            if user_id is None or suffix is None:
                if key.startswith(self._managed_runtime_prefix()):
                    unknown_keys.append(key)
                continue
            if user_id not in by_user:
                by_user[user_id] = self.inspect_user_state(user_id)
        users = [by_user[user_id] for user_id in sorted(by_user.keys())]
        degraded_users = [row for row in users if not bool(row.get("healthy", False))]
        return {
            "users": users,
            "user_count": len(users),
            "healthy": not degraded_users and not unknown_keys,
            "degraded_user_count": len(degraded_users),
            "unknown_keys": sorted(unknown_keys),
        }

    @_with_runtime_lock
    def reset_user_state(self, user_id: str) -> dict[str, Any]:
        deleted = 0
        deleted_keys: list[str] = []
        for suffix in _MANAGED_RUNTIME_SUFFIXES:
            key = self._managed_runtime_key(user_id, suffix)
            if self._db.delete_user_pref(key):
                deleted += 1
                deleted_keys.append(key)
        return {
            "user_id": str(user_id),
            "deleted_keys": deleted_keys,
            "deleted_count": deleted,
        }

    @_with_runtime_lock
    def reset_all_state(self) -> dict[str, Any]:
        rows = self._db.list_user_prefs()
        keys = [
            str((row or {}).get("key") or "").strip()
            for row in rows
            if str((row or {}).get("key") or "").strip().startswith(self._managed_runtime_prefix())
        ]
        deleted = 0
        for key in keys:
            if self._db.delete_user_pref(key):
                deleted += 1
        return {
            "deleted_count": deleted,
            "deleted_keys": sorted(keys),
        }

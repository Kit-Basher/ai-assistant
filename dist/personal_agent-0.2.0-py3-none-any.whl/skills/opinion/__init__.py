"""Opinion layer skill package."""

"""Knowledge query skill package."""

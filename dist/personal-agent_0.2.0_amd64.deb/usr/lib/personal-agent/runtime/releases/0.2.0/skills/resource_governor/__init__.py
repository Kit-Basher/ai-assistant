"""Resource governor skill package."""

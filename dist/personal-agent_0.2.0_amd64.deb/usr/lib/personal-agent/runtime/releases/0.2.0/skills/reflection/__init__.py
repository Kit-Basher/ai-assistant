"""Weekly reflection skill package."""
